# Containment assessment participant packet

Start with `report/independent-review.md`, then its permitted files.
The authoritative definitions are in `report/containment-standard.md`.
Complete `report/reviewer-assessment.json` as a separate output, preserving this
input packet unchanged. The two archive verifiers require Python 3.12 or newer
and the standard library only; no installation, credentials or network is needed.
Do not run experiment-generation modes. A passing archive verifier is not itself
a compliance decision.

The reports, worked assessment, administrator scoring page, previous reviews and
Git history are excluded. Raw experiment outputs, source and protocol records
remain available as evidence, including descriptive case names. This is answer-key
withholding, not outcome-blinded experiment design.

`manifest.json` covers all input files except itself. Its SHA256 is supplied
separately. This local packet does not restrict the reviewer's operating-system
access to other directories; the reviewer must stay within the packet.
